#include "MQTTService.h"
#include <signal.h>
using namespace std;
int keepRunning = 1;
void sig_handler(int sig)
{
    switch (sig)
    {
    case SIGINT:
    case SIGTERM:
    default:
        keepRunning = 0;
    }
}

int main(int argc, char *argv[])
{
    signal(SIGINT, sig_handler);
    signal(SIGTERM, sig_handler);

    // 初始化mqtt服务
    auto mqtt_service = MQTTService::GetInstance();
    mqtt_service->start();

    while (keepRunning)
    {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    return 0;
}