#ifndef SV_MQTT_CLIENT_H
#define SV_MQTT_CLIENT_H

#include <iostream>
#include <atomic>
#include <chrono>
#include <cstdlib>
#include <string>
#include <thread>
#include "mqtt/async_client.h"

struct SSLOption
{
    std::string trustStore;             // 公钥证书文件
    std::string keyStore;               // 私钥证书文件
    std::string privateKey;             // 私钥key文件
    std::string privateKeyPassword;     // 私钥密码
    std::string enabledCipherSuites;    // 在SSL握手过程中客户端将呈现给服务器的密码套件列表
    bool enableServerCertAuth = false;  // 是否启用启用服务器证书验证的选项
};

struct MQTTConfig
{
    std::string host;           // broker地址
    std::string clientID;       // 客户端名称，可任意取名
    int maxReconnAttempts = 5;  // 最大重连次数,为0时无重连限制
    int reconnDelayMs = 2000;   // 重连间隔时间

    //SSLOption sslOption;      // SSL选项，预留暂不支持
};

class sv_mqtt_client
{
public:
    using MessageHandler = std::function<void(const std::string& topic, const std::string& payload)>;

    /**************************************************************
     * @brief 构造函数
     * @param configs MQTT配置信息
    **/
    sv_mqtt_client(const MQTTConfig& configs);
    ~sv_mqtt_client();

    /**************************************************************
     * @brief 连接到MQTT服务器
     * @param cleanSession 是否清除会话
     * @param username 用户名
     * @param pwd 用户密码
     * @return 是否连接成功
    **/
    bool connect(bool cleanSession = true);
    bool connect(const std::string& username, const std::string& pwd, bool cleanSession = true);

    /**************************************************************
     * @brief 断开连接
    **/
    void disconnect();

    /**************************************************************
     * @brief 重新连接
    **/
    bool reconnect();
    void reconnectThread();

    /**************************************************************
     * @brief 发布消息
     * @param topic 主题
     * @param payload 消息内容
     * @param qos 服务质量等级 (0,1,2)
     * @param retained 是否保留消息
     * @return 是否发布成功
    **/
    bool publish(const std::string& topic, const std::string& payload, int qos = 1, bool retained = false);

    /**************************************************************
     * @brief 订阅主题
     * @param topic 主题
     * @param qos 服务质量等级 (0,1,2)
     * @param messageHandler 消息处理回调函数
     * @return 是否订阅成功
    **/
    bool subscribe(const std::string& topic, int qos, MessageHandler messageHandler);

    /**************************************************************
     * @brief 取消订阅
     * @param topic 主题
     * @return 是否取消订阅成功
    **/
    bool unsubscribe(const std::string& topic);

    /**************************************************************
     * @brief 检查是否已连接
     * @return 连接状态
    **/
    bool isConnected() const;

private:
    mqtt::connect_options m_connOpts;
    std::string m_clientId;
    std::unique_ptr<mqtt::async_client> m_client;
    SSLOption m_sslOption;
    std::unordered_map<std::string, MessageHandler> m_topicHandlers;

    //重连参数
    const int m_maxReconnectAttempts;
    const int m_reconnectDelayMs;
    std::atomic<int> m_reconnectAttempts{0};
    std::atomic<bool> m_manualDisconnect{false};
    std::atomic<bool> m_reconnectActive{false};
    std::mutex m_reconnectMutex;
    std::condition_variable m_reconnectCV;

    // 内部回调类
    class ActionListener : public virtual mqtt::iaction_listener
    {
    public:
        ActionListener(sv_mqtt_client& parent) : m_parent(parent) {}

        void on_failure(const mqtt::token& tok) override;
        void on_success(const mqtt::token& tok) override;

    private:
        sv_mqtt_client& m_parent;
    };

    // 消息回调类
    class MessageCallback : public virtual mqtt::callback
    {
    public:
        MessageCallback(sv_mqtt_client& parent) : m_parent(parent){}

        void message_arrived(mqtt::const_message_ptr msg) override;
        void connection_lost(const std::string& cause) override;

    private:
        sv_mqtt_client& m_parent;
        mqtt::connect_options m_connOpts;
        std::mutex m_mutex;
    };

    ActionListener m_actionListener;
    MessageCallback m_messageCallback;
};

#endif
