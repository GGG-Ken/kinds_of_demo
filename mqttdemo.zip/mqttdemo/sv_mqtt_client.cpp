#include "sv_mqtt_client.h"
#include <iostream>

sv_mqtt_client::sv_mqtt_client(const MQTTConfig& configs)
    : m_clientId(configs.clientID),
      m_client(std::make_unique<mqtt::async_client>(configs.host, configs.clientID)),
      m_maxReconnectAttempts(configs.maxReconnAttempts),
      m_reconnectDelayMs(configs.reconnDelayMs),
      //m_sslOption(configs.sslOption),
      m_actionListener(*this),
      m_messageCallback(*this)
{
    m_client->set_callback(m_messageCallback);
}

sv_mqtt_client::~sv_mqtt_client()
{
    m_manualDisconnect = true;
    disconnect();
    m_reconnectCV.notify_all();
    std::cout << "sv_mqtt_client deinit" << std::endl;
}

bool sv_mqtt_client::connect(bool cleanSession)
{
    m_manualDisconnect = false;
    m_reconnectAttempts = 0;

    m_connOpts = mqtt::connect_options_builder()
        .clean_session(cleanSession)
        .finalize();

    try
    {
        m_client->connect(m_connOpts, nullptr, m_actionListener)->wait();
        std::cout << "MQTT connection finished" << std::endl;
        return true;
    }
    catch (const mqtt::exception& exc)
    {
        std::cerr << "[MQTT]Connect error: " << exc.what() << std::endl;
        return false;
    }
}

bool sv_mqtt_client::connect(const std::string& username, const std::string& pwd, bool cleanSession)
{
    m_manualDisconnect = false;
    m_reconnectAttempts = 0;

    m_connOpts = mqtt::connect_options_builder()
        .user_name(username)
        .password(pwd)
        .clean_session(cleanSession)
        .finalize();

    try 
    {
        m_client->connect(m_connOpts, nullptr, m_actionListener)->wait();
        return true;
    }
    catch (const mqtt::exception& exc)
    {
        std::cerr << "[MQTT]Connect error: " << exc.what() << std::endl;
        return false;
    }
}

void sv_mqtt_client::disconnect()
{
    m_manualDisconnect = true;
    try
    {
        if (isConnected())
        {
            m_client->disconnect()->wait();
        }
    }
    catch (const mqtt::exception& exc)
    {
        std::cerr << "[MQTT]Disconnect error: " << exc.what() << std::endl;
    }
}

bool sv_mqtt_client::reconnect()
{
    try
    {
        m_client->connect(m_connOpts)->wait();

        // 重新订阅所有主题
        for (const auto& [topic, handler] : m_topicHandlers)
        {
            m_client->subscribe(topic, 1)->wait();
        }

        return true;
    }
    catch (const mqtt::exception& exc) {
        std::cerr << "[MQTT]Reconnect error: " << exc.what() << std::endl;
        return false;
    }
}

void sv_mqtt_client::reconnectThread()
{
    std::unique_lock<std::mutex> lock(m_reconnectMutex);

    while (!m_manualDisconnect && (m_maxReconnectAttempts == 0 || m_reconnectAttempts < m_maxReconnectAttempts))
    {

        std::cout << "[MQTT]try to reconnect (" << (m_reconnectAttempts + 1) << "/" 
                  << (m_maxReconnectAttempts == 0 ? "unlimited" : std::to_string(m_maxReconnectAttempts))
                  << ")..." << std::endl;

        if (reconnect())
        {
            std::cout << "[MQTT]Reconncet success!" << std::endl;
            m_reconnectAttempts = 0;
            m_reconnectActive = false;
            return;
        }

        m_reconnectAttempts++;

        // 等待重连间隔时间或被唤醒
        m_reconnectCV.wait_for(lock, std::chrono::milliseconds(m_reconnectDelayMs),
                            [this] { return m_manualDisconnect.load(); });
    }

    if (!m_manualDisconnect)
    {
        std::cerr << "[MQTT]the largest connection count(" << m_maxReconnectAttempts << ")，stop reconncet attemption" << std::endl;
    }

    m_reconnectActive = false;
}

bool sv_mqtt_client::publish(const std::string& topic, const std::string& payload, int qos, bool retained)
{
    try
    {
        auto msg = mqtt::make_message(topic, payload);
        msg->set_qos(qos);
        msg->set_retained(retained);

        m_client->publish(msg, nullptr, m_actionListener);
        return true;
    }
    catch (const mqtt::exception& exc)
    {
        std::cerr << "[MQTT]Publish error: " << exc.what() << std::endl;
        return false;
    }
}

bool sv_mqtt_client::subscribe(const std::string& topic, int qos, MessageHandler messageHandler)
{
    try
    {
        m_client->subscribe(topic, qos, nullptr, m_actionListener)->wait();
        m_topicHandlers[topic] = messageHandler;
        return true;
    }
    catch (const mqtt::exception& exc)
    {
        std::cerr << "[MQTT]subscribe error: " << exc.what() << std::endl;
        return false;
    }
}

bool sv_mqtt_client::unsubscribe(const std::string& topic)
{
    try
    {
        m_client->unsubscribe(topic, nullptr, m_actionListener)->wait();
        m_topicHandlers.erase(topic);
        return true;
    }
    catch (const mqtt::exception& exc)
    {
        std::cerr << "[MQTT]cannel subscription error: " << exc.what() << std::endl;
        return false;
    }
}

bool sv_mqtt_client::isConnected() const
{
    return m_client->is_connected();
}

void sv_mqtt_client::ActionListener::on_failure(const mqtt::token& tok)
{
    std::cerr << "operate fail: ";
    if (tok.get_message_id() != 0)
        std::cerr << "token[" << tok.get_message_id() << "]: ";
    std::cerr << tok.get_reason_code() << std::endl;
}

void sv_mqtt_client::ActionListener::on_success(const mqtt::token& tok)
{
    std::cout << "operate success: ";
    if (tok.get_message_id() != 0)
        std::cout << "token[" << tok.get_message_id() << "]: ";
    auto top = tok.get_topics();
    if (top && !top->empty())
        std::cout << "topic[" << (*top)[0] << "]" << std::endl;
    else
        std::cout << std::endl;
}

void sv_mqtt_client::MessageCallback::message_arrived(mqtt::const_message_ptr msg)
{
    std::string topic = msg->get_topic();
    std::string payload = msg->to_string();

    std::lock_guard<std::mutex> lock(m_mutex);

    auto it = m_parent.m_topicHandlers.find(topic);
    if (it != m_parent.m_topicHandlers.end() && it->second)
    {
        it->second(topic, payload);
    }
}

void sv_mqtt_client::MessageCallback::connection_lost(const std::string& cause)
{
    std::cerr << "Connection lost: " << (cause.empty() ? "Unknow" : cause) << std::endl;
    // 这里可以添加重连逻辑
    if (!m_parent.m_manualDisconnect)
    {
        // 启动重连线程
        if (!m_parent.m_reconnectActive.exchange(true))
            std::thread(&sv_mqtt_client::reconnectThread, &m_parent).detach();
    }
}
