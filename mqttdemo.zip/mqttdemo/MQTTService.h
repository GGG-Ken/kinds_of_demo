#ifndef _MQTTSERVICE_H_
#define _MQTTSERVICE_H_

#include "sv_mqtt_client.h"
#include <memory>
#include <filesystem>
#include <mutex>

#define HANDLER_CALLBACK(handler) std::bind(&MQTTService::handler, this, std::placeholders::_1, std::placeholders::_2)

//自定义主题
enum MQTT_TOPIC
{
    TP_HEARTBEAT,
    TP_CANTRANSFER_REQ,
    TP_CANTRANSFER_RESP,
};

static const std::unordered_map<MQTT_TOPIC, std::string> s_topics =
{
    {TP_HEARTBEAT, "/v1/shixiAP/heartbeat/req"},
    {TP_CANTRANSFER_REQ, "/v1/crrc/cantransfer/req"},
    {TP_CANTRANSFER_RESP, "/v1/crrc/cantransfer/resp"}
};

// clientID为空时MQTT会自动分配一个clientID
// 注意：不同程序(即两个或多个客户端)不能起相同的clientID，否则会不断进行重连
const std::string MQTT_CLIENT_ID{""};
const std::string MQTT_HOST{"10.66.32.242"};
const std::string MQTT_USER{""};
const std::string MQTT_PWD{""};

class MQTTService
{
public:
    static std::shared_ptr<MQTTService> GetInstance();
    MQTTService();
    ~MQTTService();

    void start();
    // 发布消息
    void publish(MQTT_TOPIC topic, const std::string &payload);
    // 订阅主题
    void subscribe(MQTT_TOPIC topic, int qos, sv_mqtt_client::MessageHandler messageHandler);

private:
    // 连接
    bool connect();

    // 订阅主题
    void subscribe_topics();
    void stop();
    void process_heartbeat(const std::string &topic, const std::string &payload);
    void process_cantransfer(const std::string &topic, const std::string &payload);

private:
    std::unique_ptr<sv_mqtt_client> m_client;
    std::string m_host;
    bool m_connect;
};

#endif
