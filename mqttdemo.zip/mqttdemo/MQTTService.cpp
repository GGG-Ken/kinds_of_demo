#include "MQTTService.h"
#include "sv_mqtt_client.h"
#include <filesystem>
#include <mutex>
#include <string>
#include <vector>
#include <sys/stat.h>
#include "kankan_proto/kankan.pb.h"

using namespace std;
shared_ptr<MQTTService> MQTTService::GetInstance()
{
    static shared_ptr<MQTTService> instance;
    if (instance == nullptr)
    {
        instance = make_shared<MQTTService>();
    }

    return instance;
}

MQTTService::MQTTService() : m_connect(false)
{
    m_host = MQTT_HOST;
    cout << "++++++++++MQTT_HOST:" << m_host << "++++++++" << endl;
    MQTTConfig configs;
    configs.clientID = MQTT_CLIENT_ID;
    configs.host = m_host;
    configs.maxReconnAttempts = 0;
    configs.reconnDelayMs = 3000;

    m_client.reset(new sv_mqtt_client(configs));
}

MQTTService::~MQTTService()
{
    m_connect = true;
    stop();
}

bool MQTTService::connect()
{
    if (!m_client->connect(MQTT_USER, MQTT_PWD))
    {
        return false;
    }

    return true;
}

void MQTTService::start()
{
    thread thread_connect([&]()
                          {
        while(!m_connect)
        {
            m_connect = connect();
            if(m_connect)
            {
                subscribe_topics();
                cout << "[MQTT]connect " << m_host << " success!" << endl;
                break;
            }
            this_thread::sleep_for(chrono::milliseconds(5000));
        } });
    thread_connect.join();
}

void MQTTService::stop()
{
    m_client->disconnect();
}

void MQTTService::publish(MQTT_TOPIC topic, const string &payload)
{
    if (m_client != nullptr && m_client->isConnected())
    {
        m_client->publish(s_topics.at(topic), payload);
    }
}

void MQTTService::subscribe(MQTT_TOPIC topic, int qos, sv_mqtt_client::MessageHandler messageHandler)
{
    if (!m_client->isConnected())
        return;

    m_client->subscribe(s_topics.at(TP_HEARTBEAT), 1, messageHandler);
}

void MQTTService::subscribe_topics()
{
    if (!m_client->isConnected())
        return;

    //订阅心跳话题
    m_client->subscribe(s_topics.at(TP_HEARTBEAT), 1, HANDLER_CALLBACK(MQTTService::process_heartbeat));
    //订阅cantransfer话题
    m_client->subscribe(s_topics.at(TP_CANTRANSFER_REQ), 1, HANDLER_CALLBACK(MQTTService::process_cantransfer));
}

void MQTTService::process_heartbeat(const string &topic, const string &payload)
{
    cout << "[MQTT]Receive Msg - topic: " << topic << endl;
    cout << "[MQTT]Payload: " << payload << endl;
}

//收到cantransfer话题处理
void MQTTService::process_cantransfer(const string &topic, const string &payload)
{
    CanTransfer content;    //接收的协议内容
    CanTransfer msg;        //要发送的协议内容
    if (!content.ParseFromString(payload))
        return;

    int32_t id = content.id();
    std::string canid = content.canid();
    std::string data = content.data();
    int32_t canChannel = content.canchannel();
    printf("[MQTT]id:%d\n", id);
    printf("[MQTT]canid:%s\n", canid.c_str());
    printf("[MQTT]data:%s\n", data.c_str());
    printf("[MQTT]canChannel:%d\n", canChannel);

    //返回话题
    msg.set_id(0);
    msg.set_canid("canid");
    msg.set_data("data");
    msg.set_canchannel(1);
    std::string str;
    msg.SerializeToString(&str);
    publish(TP_CANTRANSFER_RESP, str);
}
